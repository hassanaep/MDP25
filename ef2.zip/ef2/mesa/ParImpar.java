package ef2.mesa;
/**
 * ParImpar.Declaración de las constantes PAR, IMPAR,NADA
 */
public enum ParImpar {

	PAR,
	IMPAR,
	NADA
}
