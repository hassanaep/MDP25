package ef2.mesa;
/**
 * Color. Declaración de las constantes ROJO, NEGRO,VERDE, NADA
 */
public enum Color {

	ROJO,
	NEGRO,
	VERDE,
	NOCOLOR
}
